<template>
    <EditUserDataComponent></EditUserDataComponent>
</template>

<script>
    import EditUserDataComponent from '../components/EditUserDataComponent.vue'

    export default {
        name: "ClientHomePage",
        components: {
            EditUserDataComponent
        }
    }
</script>

<style>
    

</style>