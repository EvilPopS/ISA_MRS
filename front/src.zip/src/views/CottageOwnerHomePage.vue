<template>
    <EditUserDataComponent></EditUserDataComponent>
</template>

<script>
    import EditUserDataComponent from '../components/EditUserDataComponent.vue'

    export default {
        name: "CottageOwnerHomePage",
        components: {
            EditUserDataComponent
        }
    }
</script>

<style>
    

</style>